package com.aurionpro.jwt.dto;

import java.util.List;

import com.aurionpro.jwt.entity.Role;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class RegistrationDto {

	private String username;
	private String password;
	private String rolename;
}
